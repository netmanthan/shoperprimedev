# Copyright (c) 2023, Jawahar R Mallah and contributors
# For license information, please see license.txt

# import frappe
from frappe.model.document import Document

class POSPaymentEntryReference(Document):
	pass
