# Copyright (c) 2022, Jawahar R Mallah and contributors
# For license information, please see license.txt

# import frappe
from frappe.model.document import Document

class DeliveryChargesPOSProfile(Document):
	pass
